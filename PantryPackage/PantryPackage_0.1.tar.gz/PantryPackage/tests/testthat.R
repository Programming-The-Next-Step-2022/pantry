library('testthat')
library('PantryPackage')

test_check("PantryPackage")
